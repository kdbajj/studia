package com.example.mazebank.Views;

public enum Account_Type

{
    ADMIN,
    CLIENT
}
