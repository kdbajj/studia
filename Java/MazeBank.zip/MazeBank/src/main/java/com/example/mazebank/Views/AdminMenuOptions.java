package com.example.mazebank.Views;

public enum AdminMenuOptions {

    CREATE_CLIENT,
    CLIENTS,
    DEPOSIT
}
