package com.example.mazebank.Views;

public enum ClientMenuOptions
{

    DASHBOARD,
    TRANSACTIONS,
    ACCOUNTS
}
