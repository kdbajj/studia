const numbers = [2, 5, 7, 10, 34, 16, 879, 1];
for (let i = 0; i < numbers.length; i += 1) {
  if (numbers[i] % 2 === 0) {
    console.log(numbers[i]);
  }
}
