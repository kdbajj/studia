﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolinaDbaj_Kosmetyki
{
    internal class Kosmetyk
    {
        int numer;
        string nazwaMarki;
        string rodzajKosmetyku;
        int pojemność;
        float cena;
        int kodProduktu;
        string odcień;
        bool testowanyDermatologicznie;
        string wykończenie;
        int trwałośćWMiesiącach;
        bool wegańskie;
        static int liczbaKosmetykow = 0;

        public Kosmetyk()
        {
            liczbaKosmetykow += 1;
            this.numer = liczbaKosmetykow;
            this.nazwaMarki = "Rimmel";
            this.rodzajKosmetyku = "pomadka";
            this.pojemność=20;
            this.cena = 36.99f;
            this.kodProduktu=232;
            this.odcień="czerwony";
            this.testowanyDermatologicznie=true;
            this.wykończenie="matowe";
            this.trwałośćWMiesiącach = 12;
            this.wegańskie=false;

        }
        public Kosmetyk(int numer, string nazwaMarki, string rodzajKosmetyku, int pojemność,float cena,int numerProduktu,string odcień, bool testowanyDermatologicznie, string wykończenie, int trwałośćWMiesiącach, bool wegańskie)
        {
            liczbaKosmetykow += 1;
            this.numer = liczbaKosmetykow;
            this.nazwaMarki = "Rimmel";
            this.rodzajKosmetyku = "pomadka";
            this.pojemność = 20;
            this.cena = 36.99f;
            this.kodProduktu = 232;
            this.odcień = "czerwony";
            this.testowanyDermatologicznie = true;
            this.wykończenie = "matowe";
            this.trwałośćWMiesiącach = 12;
            this.wegańskie = false;
        }
        private int TrwałośćWLatach()
        {
            int lata = trwałośćWMiesiącach / 12;
            if (lata != 1)
            {
                MessageBox.Show ("Uwaga!", "Trwałość jest krótka(poniżej roku)", MessageBoxButtons.OK, MessageBoxIcon.Warning);//wyskakuje powiadomienie ostrzegające, że produkt nie ma długiego terminu przydatności

            }
            return lata;
        }
        private int Uczulenie()
        {
            if (testowanyDermatologicznie==true)
            {
                MessageBox.Show("Produkt może być stosowany nawet na skórę wrażliwą  na alergie.", "Produkt jest bezpieczny!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            MessageBox.Show("Jeśli jesteś podatny/a na wszelkie alergie, sprawdź skład produktu przed zakupem.", "Uwaga!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return 0;
        }
        private int NowyProdukt()
        {
            if (kodProduktu > 200)
            {
                MessageBox.Show("Jest to jeden z naszych najnowszych produktów w promocyjnej cenie.", "Okazja!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            return 0;
        }
      
        public void Wypisz(ListBox lb)
        {
            lb.Items.Add("Numer kosmetyku(kolejno):\t" + numer);
            lb.Items.Add("Nazwa marki:" + nazwaMarki);
            lb.Items.Add("rodzaj kosmetyku:" + rodzajKosmetyku);
            lb.Items.Add("Pojemność: " +pojemność); 
            lb.Items.Add("Cena produktu: "+cena);
            lb.Items.Add("Kod produktu: " + kodProduktu+NowyProdukt());
            lb.Items.Add("Odcień: " + odcień);
            lb.Items.Add("Testowany dermatologicznie: " + testowanyDermatologicznie+Uczulenie());
            lb.Items.Add("Wykończenie: " + wykończenie);
            lb.Items.Add("Trwałość (w miesiącach): " + trwałośćWMiesiącach);
            lb.Items.Add("Wegański produkt: " + wegańskie);
            lb.Items.Add("Trwałość w latach: " + TrwałośćWLatach());
            
        }
        public Kosmetyk(Kosmetyk O)
         {
            liczbaKosmetykow += 1;
            this.numer = liczbaKosmetykow;
            this.nazwaMarki = O.nazwaMarki;
            this.rodzajKosmetyku = O.rodzajKosmetyku;
            this.pojemność = O.pojemność;
            this.cena = O.cena;
            this.kodProduktu = O.kodProduktu;
            this.odcień = O.odcień;
            this.testowanyDermatologicznie =O.testowanyDermatologicznie;
            this.wykończenie = O.wykończenie;
            this.trwałośćWMiesiącach =O.trwałośćWMiesiącach;
            this.wegańskie = O.wegańskie;

        }
    ~Kosmetyk()
        {
            MessageBox.Show("Likwidacja obiektu klasy Kosmetyk.");
        }
     
    }
}
