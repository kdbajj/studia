﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolinaDbaj_Kosmetyki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //public ListBox ListBoxKosmetyk { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
            Kosmetyk o1 = new Kosmetyk();
            o1.Wypisz(listBoxKosmetyk);

            Kosmetyk o2 = new Kosmetyk(2,"Maybelline","Cienie do oczu",15,50.55f,435,"kolorowy",true,"połyskujące",15,true);
            o2.Wypisz(listBoxKosmetyk);

            Kosmetyk o3 = new Kosmetyk();
            o3.Wypisz(listBoxKosmetyk);
        }
    }
    


}

